#pragma once

#define _LINUX_
