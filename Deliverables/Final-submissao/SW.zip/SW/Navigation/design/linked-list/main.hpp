#ifndef MAIN_H
#define MAIN_H

#define _LINUX_

#define DEBUG

#endif