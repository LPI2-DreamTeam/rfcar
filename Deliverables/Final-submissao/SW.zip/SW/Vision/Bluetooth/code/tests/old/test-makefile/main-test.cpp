#include "test.h"

int main(void)
{
    Test t = Test();
    t.print();
}
