#include <iostream>
#include "test.h"

void Test::print()
{
    std::cout << "Hello Test" << std::endl;
}
