class Test
{
public:
    void print();  
};
