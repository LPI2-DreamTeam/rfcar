#!/bin/bash
# determine shell: $SHELL
sudo apt install libbluetooth-dev
