package com.example.btapp;

public class YoutubeConfig {
    public YoutubeConfig(){
    }

    private static final String API_KEY = "AIzaSyB6KUU4-W0u0qtBPyxPnJ0BAmfLpngt1JM";

    public static String getApiKey(){
        return API_KEY;
    }
}
